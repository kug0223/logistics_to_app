import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

/// AlFit 스플래시 화면
/// 
/// 사용법:
/// MaterialApp의 home에 SplashScreen()을 설정하거나
/// 라우팅에서 초기 화면으로 설정
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    
    // 애니메이션 컨트롤러
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    // 페이드 인 애니메이션
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.0, 0.6, curve: Curves.easeIn),
    ));

    // 스케일 애니메이션
    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.0, 0.6, curve: Curves.easeOutBack),
    ));

    // 애니메이션 시작
    _controller.forward();

    // 2초 후 메인 화면으로 이동
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        _navigateToHome();
      }
    });
  }

  void _navigateToHome() {
    // TODO: 실제 홈 화면으로 교체하세요
    // Navigator.pushReplacement(
    //   context,
    //   MaterialPageRoute(builder: (context) => const HomeScreen()),
    // );
    print('Navigate to home screen');
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // 다크모드 감지
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final backgroundColor = isDark ? const Color(0xFF121212) : Colors.white;
    final logoPath = isDark 
        ? 'assets/images/logo_splash_dark.svg' 
        : 'assets/images/logo_splash_light.svg';

    return Scaffold(
      backgroundColor: backgroundColor,
      body: Center(
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            return Opacity(
              opacity: _fadeAnimation.value,
              child: Transform.scale(
                scale: _scaleAnimation.value,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // 로고
                    SvgPicture.asset(
                      logoPath,
                      width: MediaQuery.of(context).size.width * 0.7,
                      height: 200,
                    ),
                    
                    const SizedBox(height: 40),
                    
                    // 로딩 인디케이터 (선택사항)
                    SizedBox(
                      width: 40,
                      height: 40,
                      child: CircularProgressIndicator(
                        strokeWidth: 3,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          isDark ? Colors.white : const Color(0xFF1976D2),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}


/// ============================================================
/// 대안: 더 심플한 스플래시 화면 (애니메이션 없음)
/// ============================================================

class SimpleSplashScreen extends StatefulWidget {
  const SimpleSplashScreen({super.key});

  @override
  State<SimpleSplashScreen> createState() => _SimpleSplashScreenState();
}

class _SimpleSplashScreenState extends State<SimpleSplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigateToHome();
  }

  void _navigateToHome() {
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        // TODO: 실제 홈 화면으로 교체
        // Navigator.pushReplacement(
        //   context,
        //   MaterialPageRoute(builder: (context) => const HomeScreen()),
        // );
        print('Navigate to home screen');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final backgroundColor = isDark ? const Color(0xFF121212) : Colors.white;
    final logoPath = isDark 
        ? 'assets/images/logo_splash_dark.svg' 
        : 'assets/images/logo_splash_light.svg';

    return Scaffold(
      backgroundColor: backgroundColor,
      body: Center(
        child: SvgPicture.asset(
          logoPath,
          width: MediaQuery.of(context).size.width * 0.7,
          height: 200,
        ),
      ),
    );
  }
}


/// ============================================================
/// 사용법 예시 - main.dart
/// ============================================================

/*
import 'package:flutter/material.dart';
import 'splash_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AlFit',
      theme: ThemeData(
        brightness: Brightness.light,
        primaryColor: const Color(0xFF1976D2),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1976D2),
        ),
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFF2196F3),
      ),
      home: const SplashScreen(), // 👈 여기!
    );
  }
}
*/


/// ============================================================
/// pubspec.yaml 설정
/// ============================================================

/*
dependencies:
  flutter:
    sdk: flutter
  flutter_svg: ^2.0.9  # SVG 로고 표시용

flutter:
  assets:
    - assets/images/logo_splash_light.svg
    - assets/images/logo_splash_dark.svg
*/
